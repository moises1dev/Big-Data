#!/usr/bin/env python

import sys
from src.ingest.api_ingest import main

if __name__ == "__main__":
    sys.exit(main())
