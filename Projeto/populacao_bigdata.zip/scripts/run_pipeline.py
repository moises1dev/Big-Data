#!/usr/bin/env python

import sys
from src.pipelines.pyspark_pipeline import run

if __name__ == "__main__":
    run()
